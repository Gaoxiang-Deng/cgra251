/// @ref core
/// @file glm/matrix.hpp

#include "detail/setup.hpp"

#pragma once

#include "detail/func_matrix.hpp"
